package com.example.user.myapplication;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, 5);
        }
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(1);
        final TextView txt = new TextView(this);
        txt.setText("\n");
        txt.setTextSize(18);
        layout.addView(txt);
        Button input = new Button(this);
        input.setText("음성 입력");
        input.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputVoice(txt);
            }
        });
        layout.addView(input);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(layout);
        setContentView(scroll);
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                tts.setLanguage(Locale.KOREAN);
            }
        });
    }

    public void inputVoice(final TextView txt) {
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, this.getPackageName());
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR");
            final SpeechRecognizer stt = SpeechRecognizer.createSpeechRecognizer(this);
            stt.setRecognitionListener(new RecognitionListener() {
                @Override
                public void onReadyForSpeech(Bundle params) {
                    toast("음성 입력 시작...");
                }

                @Override
                public void onBeginningOfSpeech() {

                }

                @Override
                public void onRmsChanged(float rmsdB) {

                }

                @Override
                public void onBufferReceived(byte[] buffer) {
                }

                @Override
                public void onEndOfSpeech() {
                    toast("음성 입력 종료");
                }

                @Override
                public void onError(int error) {
                    toast("오류 발생 : " + error);
                    stt.destroy();
                }

                @Override
                public void onResults(Bundle results) {
                    ArrayList<String> result = (ArrayList<String>) results.get(SpeechRecognizer.RESULTS_RECOGNITION);
                    txt.append("[나] "+result.get(0)+"\n");
                    replyAnswer(result.get(0), txt);
                    stt.destroy();
                }

                @Override
                public void onPartialResults(Bundle partialResults) {

                }

                @Override
                public void onEvent(int eventType, Bundle params) {

                }
            });
            stt.startListening(intent);
        } catch (Exception e) {
            toast(e.toString());
        }
    }


    private void replyAnswer(String input, TextView txt){

        //0기능 안내
        String mirrorFunc[] = {"기능", "기넝", "기눙", "긔눙", "긴응" ,
                "기능 마래 줘", "기능 말해 줘", "기능 말해" ,"기능 말 해","기능  뭐야"," 기능 머야","기능 마래", "기능 뭐 있냐", "기능 뭐있냐", "기능 뭐있어", "기능 뭐 있어","기능 뭐뭐 있어","기능 뭐 뭐 있어","기능 뭐냐","기능 머냐","기능 모냐","기능 말해주","기능 말해 주"};

        //내부처리되는 명령(show/hide)

            //11내부조명
            String showInnerLight[] = {"거울조명 켜줘","거울 조명 켜줘","거울 조명 켜 줘", "거울 조명 켜","거울 조명 키자","거울조명 켜","거울조명 키자","거울조명 켜죠","거울조명 켜 죠","거울 조명 켜 죠","거울저명 켜줘","거울 저명 켜 줘","거울 저명 켜 줘" };
            String hideInnerLight[] = {"거울조명 꺼줘","거울 조명 꺼줘","거울 조명 꺼 줘", "거울 조명 꺼","거울 조명 끄자","거울조명 꺼","거울조명 끄자","거울조명 꺼죠","거울조명 꺼 죠","거울 조명 꺼 죠","거울저명 꺼줘","거울 저명 꺼 줘","거울 저명 꺼 줘" };

            //12메모
            String showMemo[] = {"메모 켜 줘","메모 켜","메모 켜줘","메모 켜죠","메모 켜 죠","메모 켜쥬","메모 켜 쥬","매모 켜줘","매모 켜 줘","매모 켜","매모 켜죠","매모 켜 죠"};
            String hideMemo[] = {"메모 꺼 줘","메모 꺼줘","메모 꺼","메모 꺼죠","메모 꺼 죠","메모 꺼쥬","메모 꺼 쥬","메 모 꺼 줘" };

            //13일정
            String showCalendar[] = {"일정 보여 줘","일정 보여줘","일 정 보 여 줘","일정 보여줘","일 정","일쩡 보여 줘","일쩡 보여줘","일정 보여죠","일정 보여쥬","일정 뭐야","일정 어떻게 돼","일정 알려줘","일정 알려 줘" };
            String hideCalendar[] = {"일정 꺼줘","일정 꺼져","일 정 꺼 줘","일정꺼줘","일정 꺼","일정 꺼죠","일정 그만","일정꺼조" };

        //end of 내부처리되는 명령(show/hide)

        //주변기기제어 관련 명령(on/off)

            //21 외부조명
            String onOuterLight[] = {"외부조명 켜줘","외부조명 켜 줘","외부 조명 켜 줘","외부 조명 켜줘","외부 조명 켜줘","외부 조명 켜 줘","외부 조명 켜져","외부 조명 켜 져","외부 조명 켜","외부조명 켜"};
            String offOuterLight[] = {"외부조명 꺼줘","외부조명 꺼 줘","외부 조명 꺼 줘","외부 조명 꺼줘","외부 조명 꺼줘","외부 조명 꺼 줘","외부 조명 꺼져","외부조명 꺼 져","외부 조명 꺼","외부조명 꺼"};

            //22 선풍기
            String onFan[] = {"선풍기"," 성풍기", "성푼기", "선퐁기", "성풍긔", "선풍긔",
                    "선풍기 켜줘","선풍기 켜죠","선풍기 켜 줘", "선풍기 켜 죠","성풍기 켜줘","성풍기 켜죠","선풍기 켜","선풍기 켜주"};
            String offFan[] = {"선풍기 꺼","선풍기 꺼줘","선풍기 꺼 줘","선풍기 꺼죠","선풍기 꺼 죠","선풍기 꺼져","선풍기 끄자"};

        //end of 주변기기제어 관련 명령(on/off)

        //외부입력값 관련 명령(open,on/close,off)
            //31 자동문(cctv)
            String openDoor[] = {"문 열어줘","문 열 어 줘", "문 열어 줘","문 열어","문 열려","문 열어봐","문 잠금해제","문 잠금 해제","문 열자","문 열어요"};
            String closeDoor[] = {"문 닫아줘","문 닫 아 줘","문 닫아 줘","문 닫아","문 닫어","문 닫아봐","문 닫어봐"," 문 잠가","문 잠궈","문 잠구어","문 잠가라","문 잠그자","문 닫자","문 닫아요","문 닫으라고"};

            //32온습도
            String onTemp[] = {"온도 알려 줘","온도 알려줘","온 도 알 려 줘","온 도 알려줘","온도","온도 알려죠","온도 알려 져","언도 알려줘","언도 알려 줘","습도 알려 줘","습도 알려줘","습 도 알 려 줘","습 도 알려줘","습도","습도 알려죠","습도 알려 져"};
            String offTemp[] = {"온도 꺼줘","온도 꺼","온 도 꺼 줘","온도 꺼죠","온도꺼","온도 그만","온도꺼죠","온도 꺼져","온도꺼져","습도 꺼 줘","습도 꺼줘","습 도 꺼 줘","습도 꺼죠","습도꺼죠","습도끄라고","습도 끄라고"};

        //end of 외부입력값 관련 명령(open,on/close,off)

        //질문 2회이상지속되는 명령
        //41버스
        String showBus[] = {"버스"," 뻐쓰", "뽀쓰"," 보스","뻐쑤",
                "버스 어디야","버스 오디야","버스 어디 야","버스 오디 야",
                "버스 시간 보여 줘","버스 시간보여줘","버스 시간","버스 시간 보여줘","버스 시간 버여져","버스 시간 버여 져","버스 시간 봐봐","버스 시간 봐 봐" };
        String hideBus[] = {};

        //42날씨
        String showWeather[] = {"날씨", "나씨","널씨", "날씨 알려줘","날씨 알려 줘","날씨 알려죠","날씨 알려 죠","날씨 아려줘","날씨 아려 줘","날씨 알려져","날씨 알려 져","날씨 알러져"};
        String hideWeather[] = {};


        String var;//음성출력값옵션스츠링
        int optionNum;
        try{
            if(Arrays.asList(mirrorFunc).contains(input)){
                var = "안녕하세요";
                optionNum = 0;
                txt.append("[스마트미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);

            }
            else if(Arrays.asList(showInnerLight).contains(input)){
                var = "거울 조명을 켜드릴게요.";
                optionNum = 111;
                txt.append("[스마트 미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);
            }

            else if(Arrays.asList(hideInnerLight).contains(input)){
                var = "거울 조명을 꺼드릴게요.";
                optionNum = 110;
                txt.append("[스마트 미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);
            }

            else if(Arrays.asList(showMemo).contains(input)){
                var = "메모를 보여드릴게요";
                optionNum = 121;
                txt.append("[스마트 미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);
            }

            else if(Arrays.asList(hideMemo).contains(input)){
                var = "메모를 꺼드릴게요";
                optionNum = 120;
                txt.append("[스마트 미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);
            }

            else if(Arrays.asList(showCalendar).contains(input)){
                var = "일정을 보여드릴게요";
                optionNum = 131;
                txt.append("[스마트 미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);
            }

            else if(Arrays.asList(hideCalendar).contains(input)){
                var = "일정을 꺼드릴게요";
                optionNum = 130;
                txt.append("[스마트 미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);
            }

            else if(Arrays.asList(onOuterLight).contains(input)){
                var = "외부 조명을 켜드릴게요.";
                optionNum = 211;
                txt.append("[스마트 미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);
            }

            else if(Arrays.asList(offOuterLight).contains(input)){
                var = "외부 조명을 꺼드릴게요.";
                optionNum = 210;
                txt.append("[스마트 미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);
            }

            else if(Arrays.asList(onFan).contains(input)){
                var = "선풍기를 켜드릴게요.";
                optionNum = 221;
                txt.append("[스마트 미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);
            }

            else if(Arrays.asList(offFan).contains(input)){
                var = "선풍기를 꺼드릴게요.";
                optionNum = 220;
                txt.append("[스마트 미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);
            }

            else if(Arrays.asList(openDoor).contains(input)){
                var = "문을 열어드릴게요.";
                optionNum = 311;
                txt.append("[스마트 미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);
            }

            else if(Arrays.asList(closeDoor).contains(input)){
                var = "문을 닫아드릴게요.";
                optionNum = 310;
                txt.append("[스마트 미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);
            }

            else if(Arrays.asList(onTemp).contains(input)){
                var = "온도와 습도를 켜드릴게요.";
                optionNum = 321;
                txt.append("[스마트 미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);
            }

            else if(Arrays.asList(offTemp).contains(input)){
                var = "온도와 습도를 꺼드릴게요.";
                optionNum = 320;
                txt.append("[스마트 미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);
            }

            else if(Arrays.asList(showBus).contains(input)){
                var = "어떤 버스를 알려드릴까요?";
                optionNum = 410;
                txt.append("[스마트 미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);
            }

            else if(Arrays.asList(hideBus).contains(input)){
                var = "번 버스를 알려드릴게요.";
                optionNum = 411;
                txt.append("[스마트 미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);
            }

            else if(Arrays.asList(showWeather).contains(input)){
                var = "어디 날씨를 알려드릴까요?";
                optionNum = 420;
                txt.append("[스마트 미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);
            }

            else if(Arrays.asList(hideWeather).contains(input)){
                var = "날씨를 알려드릴게요.";
                optionNum = 421;
                txt.append("[스마트 미러] "+var+" \n");
                tts.speak(var, TextToSpeech.QUEUE_FLUSH, null);
            }


            else if(input.equals("종료")){
                finish();
            }
            else {
                txt.append("스마트미러 : 다시 한번만 말씀해주세요\n");
                tts.speak("다시 한번만 말씀해주세요", TextToSpeech.QUEUE_FLUSH, null);
            }
        } catch (Exception e) {
            toast(e.toString());
        }
    }

    private void toast(String msg){
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

}
